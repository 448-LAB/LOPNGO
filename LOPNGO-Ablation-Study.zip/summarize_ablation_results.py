"""
消融实验结果汇总脚本
此脚本用于汇总所有函数的消融实验结果，生成一个综合表格和对比图
"""

import os
import re
import glob
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.ticker import ScalarFormatter
import platform

# 设置字体和样式，确保中文显示正确
system = platform.system()
if system == 'Windows':
    plt.rcParams['font.sans-serif'] = ['SimHei', 'Microsoft YaHei', 'DejaVu Sans', 'Arial']
else:
    plt.rcParams['font.sans-serif'] = ['DejaVu Sans', 'Arial']

plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['font.family'] = 'sans-serif'

def parse_ablation_result(filepath):
    """解析单个消融实验结果文件"""
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 提取函数名称
    func_name_match = re.search(r"正在进行\s+(\S+)函数\s+渐进式消融实验", content)
    if not func_name_match:
        return None
    func_name = func_name_match.group(1)
    
    # 提取表格数据
    # 使用正则表达式匹配表格行
    table_pattern = r"(NGO|LNGO|LPNGO|LONGO|LOPNGO)\s+([0-9.-]+e[+-][0-9]+)\s+([0-9.-]+e[+-][0-9]+)\s+([0-9.-]+e[+-][0-9]+)\s+([0-9.-]+e[+-][0-9]+)\s+([0-9.]+)\s+([0-9.]+)\s+([0-9]+)\s+([0-9.-]+)"
    table_matches = re.findall(table_pattern, content)
    
    if not table_matches:
        return None
    
    # 解析表格数据
    results = []
    for match in table_matches:
        algorithm = match[0]
        best_value = float(match[1])
        worst_value = float(match[2])
        mean_value = float(match[3])
        std_dev = float(match[4])
        success_rate = float(match[5])
        avg_time = float(match[6])
        time_rank = int(match[7])
        improvement = float(match[8])
        
        results.append({
            "函数": func_name,
            "算法": algorithm,
            "最优值": best_value,
            "最差值": worst_value,
            "平均值": mean_value,
            "标准差": std_dev,
            "成功率(%)": success_rate,
            "平均时间(s)": avg_time,
            "时间排名": time_rank,
            "改进率(%)": improvement
        })
    
    return results

def create_summary_table(input_dir):
    """创建所有函数结果的汇总表格"""
    # 查找所有结果文件
    pattern = os.path.join(input_dir, "progressive_ablation_f*.txt")
    result_files = glob.glob(pattern)
    
    if not result_files:
        print(f"错误: 在'{input_dir}'目录中未找到结果文件")
        return None
    
    # 解析所有文件
    all_results = []
    for file in result_files:
        results = parse_ablation_result(file)
        if results:
            all_results.extend(results)
    
    if not all_results:
        print("错误: 未能从文件中解析出有效结果")
        return None
    
    # 创建DataFrame
    df = pd.DataFrame(all_results)
    
    # 保存到CSV
    output_csv = os.path.join(input_dir, "ablation_summary.csv")
    df.to_csv(output_csv, index=False, encoding='utf-8-sig')
    print(f"汇总表格已保存为: {output_csv}")
    
    return df

def create_summary_plots(df, output_dir):
    """创建汇总对比图"""
    if df is None or df.empty:
        return
    
    # 为每个算法绘制平均值和改进率对比图
    algorithms = ["NGO", "LNGO", "LPNGO", "LONGO", "LOPNGO"]
    functions = df["函数"].unique()
    
    # 颜色和标记映射
    colors = ['gray', 'green', 'blue', 'cyan', 'red']
    markers = ['o', '^', 's', '<', '*']
    
    # 1. 平均值对比图 (对数刻度)
    plt.figure(figsize=(15, 10))
    
    for i, algo in enumerate(algorithms):
        algo_data = df[df["算法"] == algo]
        if not algo_data.empty:
            plt.semilogy(algo_data["函数"], algo_data["平均值"], 
                       color=colors[i], marker=markers[i], markersize=10,
                       linestyle='-', linewidth=2, label=algo)
    
    plt.title("各算法在不同函数上的平均值对比 (对数刻度)", fontsize=16)
    plt.xlabel("测试函数", fontsize=14)
    plt.ylabel("平均目标函数值 (对数刻度)", fontsize=14)
    plt.grid(True, alpha=0.3)
    plt.legend(loc="best", fontsize=12)
    plt.tight_layout()
    
    plt.savefig(os.path.join(output_dir, "algorithms_mean_comparison.png"), dpi=300, bbox_inches="tight")
    print(f"平均值对比图已保存")
    
    # 2. 改进率对比图
    plt.figure(figsize=(15, 10))
    
    for i, algo in enumerate(algorithms[1:]):  # 跳过NGO，因为它的改进率总是0
        algo_data = df[df["算法"] == algo]
        if not algo_data.empty:
            plt.bar([f"{func}\n({algo})" for func in algo_data["函数"]], 
                   algo_data["改进率(%)"], 
                   color=colors[i+1], alpha=0.7,
                   label=f"{algo} vs NGO")
    
    plt.title("各改进算法相对于NGO的改进率对比", fontsize=16)
    plt.xlabel("测试函数", fontsize=14)
    plt.ylabel("改进率 (%)", fontsize=14)
    plt.grid(True, alpha=0.3, axis='y')
    plt.legend(loc="best", fontsize=12)
    plt.tight_layout()
    
    plt.savefig(os.path.join(output_dir, "improvement_rate_comparison.png"), dpi=300, bbox_inches="tight")
    print(f"改进率对比图已保存")
    
    # 3. 各算法在所有函数上的综合表现
    plt.figure(figsize=(12, 8))
    
    # 计算每个算法在所有函数上的平均改进率
    algo_avg_improvement = {}
    for algo in algorithms[1:]:  # 跳过NGO
        algo_data = df[df["算法"] == algo]
        if not algo_data.empty:
            algo_avg_improvement[algo] = algo_data["改进率(%)"].mean()
    
    # 绘制柱状图
    plt.bar(algo_avg_improvement.keys(), algo_avg_improvement.values(), color=colors[1:])
    
    plt.title("各算法在所有函数上的平均改进率", fontsize=16)
    plt.xlabel("算法", fontsize=14)
    plt.ylabel("平均改进率 (%)", fontsize=14)
    plt.grid(True, alpha=0.3, axis='y')
    
    # 在柱状图上添加数值标签
    for algo, improvement in algo_avg_improvement.items():
        plt.text(algo, improvement + 1, f"{improvement:.2f}%", 
                ha='center', va='bottom', fontsize=12)
    
    plt.tight_layout()
    
    plt.savefig(os.path.join(output_dir, "algorithms_avg_improvement.png"), dpi=300, bbox_inches="tight")
    print(f"平均改进率对比图已保存")
    
    # 尝试显示图表（如果在交互式环境中）
    try:
        plt.show()
    except:
        pass

def main():
    input_dir = "LOPNGO_Ablation_Results"  # 输入目录，包含所有实验结果
    
    # 检查目录是否存在
    if not os.path.exists(input_dir):
        print(f"错误: 目录'{input_dir}'不存在!")
        return
    
    # 创建汇总表格
    print(f"开始解析'{input_dir}'目录中的实验结果...")
    summary_df = create_summary_table(input_dir)
    
    # 创建汇总图表
    if summary_df is not None:
        print("开始创建汇总图表...")
        create_summary_plots(summary_df, input_dir)
        
        print("\n汇总完成！")
        print(f"- 汇总表格: {os.path.join(input_dir, 'ablation_summary.csv')}")
        print(f"- 平均值对比图: {os.path.join(input_dir, 'algorithms_mean_comparison.png')}")
        print(f"- 改进率对比图: {os.path.join(input_dir, 'improvement_rate_comparison.png')}")
        print(f"- 平均改进率图: {os.path.join(input_dir, 'algorithms_avg_improvement.png')}")
    else:
        print("汇总失败，未能创建有效的汇总表格")

if __name__ == "__main__":
    main()
