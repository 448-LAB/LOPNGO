import os
import re
import codecs

# 修复文件编码和语法问题
def fix_file_encoding(file_path):
    try:
        # 尝试以 UTF-8 编码读取文件
        with codecs.open(file_path, 'r', 'utf-8') as f:
            content = f.read()
        
        # 替换所有特殊字符
        replacements = [
            # 文件开头部分
            (r'比较LOPNGO算法的三个改进点各自的贡献及其组合效�?', '比较LOPNGO算法的三个改进点各自的贡献及其组合效果'),
            (r'本实验包含以下算法变�?', '本实验包含以下算法变体:'),
            (r'- 两个双改进点的变�?LO和OP\)', '- 两个双改进点的变体(LO和OP)'),
            
            # 设置和配置
            (r'# 设置matplotlib字体和负号显�?', '# 设置matplotlib字体和负号显示'),
            (r'# 使用Agg后端，确保图形渲染稳�?', '# 使用Agg后端，确保图形渲染稳定'),
            (r'# 重置所有rcParams为默认�?', '# 重置所有rcParams为默认值'),
            (r'# 设置字体和样�?', '# 设置字体和样式'),
            (r'# 确保负号和数学符号显示正�?', '# 确保负号和数学符号显示正常'),
            
            # 函数和算法
            (r'# 定义额外的测试函�?', '# 定义额外的测试函数'),
            (r'"""Michalewicz函数 - 高度多模态，有陡峭山谷和局部最�?""', '"""Michalewicz函数 - 高度多模态，有陡峭山谷和局部最优"""'),
            (r'"""Levy函数 - 多模态，有很多局部最�?""', '"""Levy函数 - 多模态，有很多局部最优"""'),
            (r'"""Yang函数 - 对Levy飞行特性的算法有优�?""', '"""Yang函数 - 对Levy飞行特性的算法有优势"""'),
            
            # 注释
            (r'# 初始化种�?', '# 初始化种群'),
            (r'# 计算初始适应�?', '# 计算初始适应度'),
            (r'# 初始化收敛曲�?', '# 初始化收敛曲线'),
            (r'# 开始迭代优�?', '# 开始迭代优化'),
            
            # 特殊符号
            (r'if r2 < 0.5:  # �?\(3\)', 'if r2 < 0.5:  # 式(3)'),
            (r'else:  # �?\(4\)', 'else:  # 式(4)'),
            (r'else:  # 开发阶段，�?\(6\) \(7\)', 'else:  # 开发阶段，式(6) (7)'),
            
            # 其他文本
            (r'# 更新适应�?', '# 更新适应度'),
            (r'# 更新全局最�?', '# 更新全局最优'),
            (r'NGO变体2: 仅包含反向精英学习改�?', 'NGO变体2: 仅包含反向精英学习改进'),
            (r'NGO变体3: 仅包含小孔成像改�?', 'NGO变体3: 仅包含小孔成像改进'),
            
            # 表格和标题
            (r'\["函数名称", "算法名称", "最佳�?, "最差�?, "平均�?, "标准�?, "平均运行时间\(�?", "排名"\]', 
             '["函数名称", "算法名称", "最佳值", "最差值", "平均值", "标准差", "平均运行时间(秒)", "排名"]'),
            
            # 打印消息
            (r'print\(f"    运行 {run\+1}/{runs} - 最佳得�? {best_score:.6e}, 耗时: {execution_time:.4f}�?\)', 
             'print(f"    运行 {run+1}/{runs} - 最佳得分: {best_score:.6e}, 耗时: {execution_time:.4f}秒")'),
            (r'print\(f"    警告：算�?{algo_name} 没有有效的收敛曲�?\)', 
             'print(f"    警告：算法{algo_name} 没有有效的收敛曲线")'),
            (r'# 提供一个默认曲�?', '# 提供一个默认曲线'),
            (r'print\(f"选定函数的收敛性能对比图已保存�?{results_dir} 目录"\)', 
             'print(f"选定函数的收敛性能对比图已保存到{results_dir} 目录")'),
            (r'print\("消融实验完成�?\)', 'print("消融实验完成！")'),
            
            # 特殊算法名称
            (r'# ==================== LONGO算法（Levy飞行\+反向精英�?\)====================', 
             '# ==================== LONGO算法（Levy飞行+反向精英）===================='),
            (r'# ==================== OPNGO算法（反向精�?小孔成像�?\)====================', 
             '# ==================== OPNGO算法（反向精英+小孔成像）===================='),
            
            # 一些常见的问题字符
            (r'没有找到.*?的数�?', '没有找到$1的数据'),
            (r'ax\.text\(0\.5, 0\.5, f"没有找到{func_name}的数�?', 'ax.text(0.5, 0.5, f"没有找到{func_name}的数据"'),
        ]
        
        # 应用所有替换
        for pattern, replacement in replacements:
            content = re.sub(pattern, replacement, content)
        
        # 重新以UTF-8写入文件
        with codecs.open(file_path, 'w', 'utf-8') as f:
            f.write(content)
        
        print(f"成功修复文件: {file_path}")
        return True
    
    except Exception as e:
        print(f"修复文件时出错: {e}")
        return False

# 修复指定文件
file_path = r'd:\研究生\王硕学长\WangShuo\研究生实验代码\改进SSA代码\其他基本智能算法\LOPNGO_Ablation_Study.py'
fix_file_encoding(file_path)
