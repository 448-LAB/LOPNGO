"""
针对ONGO算法的消融实验，运行原始LOPNGO_Ablation_Study.py包含ONGO算法
"""
import os
import subprocess

# 运行原始消融实验程序
print("开始运行包含ONGO算法的消融实验...")
subprocess.call(["python", "改进SSA代码/其他基本智能算法/LOPNGO_Ablation_Study.py"])
print("ONGO算法消融实验完成！")
