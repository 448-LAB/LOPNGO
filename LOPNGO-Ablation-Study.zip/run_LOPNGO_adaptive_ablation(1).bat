@echo off
echo 运行LOPNGO自适应算法消融实验...
python LOPNGO_Ablation_Study_new.py
echo 实验完成！
pause
