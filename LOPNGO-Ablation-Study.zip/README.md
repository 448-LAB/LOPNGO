# LOPNGO Ablation Study

This repository contains scripts for running and summarizing ablation experiments for the LOPNGO optimization algorithm and its variants.

## Requirements

- Python 3.9 or later
- `numpy`
- `pandas`
- `matplotlib`

Install the dependencies with:

```bash
python -m pip install -r requirements.txt
```

## Usage

1. Place the main LOPNGO experiment source code and benchmark data in the project directory.
2. Run an experiment from a terminal, for example:

```bash
python run_LOPNGO_with_ONGO_ablation(1).py
```

Windows users can also run one of the provided `.bat` files by double-clicking it or executing it from Command Prompt.

After experiment result files have been generated in `LOPNGO_Ablation_Results/`, create the summary table and comparison figures with:

```bash
python summarize_ablation_results.py
```

The summary script generates a CSV file and PNG comparison plots in `LOPNGO_Ablation_Results/`.

## Files

- `run_LOPNGO_with_ONGO_ablation(1).py`: launches the ONGO-related ablation experiment.
- `summarize_ablation_results.py`: summarizes experiment results and creates figures.
- `run_*.bat`: Windows launch scripts.
- `fix_encoding.py`: utility for repairing encoding issues in legacy source files.

## Notes

Some launch scripts refer to legacy source paths that are not included in this repository. Update those paths before running the corresponding script.
