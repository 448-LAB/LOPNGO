@echo off
echo 开始运行包含ONGO算法的LOPNGO消融实验...
python run_LOPNGO_with_ONGO_ablation.py
pause
