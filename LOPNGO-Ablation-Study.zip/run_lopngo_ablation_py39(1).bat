@echo off
call D:\Anaconda\Scripts\activate.bat py39
python "%~dp0\改进SSA代码\其他基本智能算法\LOPNGO_Ablation_Study.py"
pause
